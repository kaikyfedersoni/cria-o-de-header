#ifndef CALCULADORA_H_INCLUDED
#define CALCULADORA_H_INCLUDED
void soma(double x,double y)
{
printf("A soma eh igual a %.2lf\n",x+y);
}
void subtracao(double x,double y)
{
printf("A substracao eh igual a %.2lf\n",x-y);
}
void multiplicacao(double x,double y)
{
printf("A multiplicacao eh igual a %.2lf\n",x*y);
}
void divisao(double x,double y)
{
printf("A divisao eh igual a %.2lf\n",x/y);
}


#endif // CALCULADORA_H_INCLUDED
