#include <stdio.h>
#include <stdlib.h>
#include "calculadora.h"
int main ()
{
double x,y;
scanf("%lf%lf",&x,&y);
soma(x,y);
subtracao(x,y);
multiplicacao(x,y);
divisao(x,y);
}
